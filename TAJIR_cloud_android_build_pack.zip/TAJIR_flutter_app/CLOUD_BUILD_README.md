# TAJIR cloud Android build pack

This repository pack lets GitHub Actions build an installable **debug/test APK** using a hosted Linux runner. You do not need to install Android Studio, the Android SDK, Flutter, Java, or Gradle on your phone.

## What this does
- Uses the TAJIR Flutter source in this folder.
- Generates standard Android project files and the Gradle wrapper on the cloud runner.
- Builds `app-debug.apk`.
- Saves the APK as a downloadable GitHub Actions artifact named `TAJIR-android-test-apk` for 14 days.

## One-time setup
1. Sign in to GitHub and create a **new private repository** named `tajir-android`.
2. Upload the contents of this pack to the repository's `main` branch. Keep the `.github/workflows/android-apk.yml` file at exactly that path and keep `pubspec.yaml` at the repository root.
3. Open the repository's **Actions** tab. If GitHub asks, enable Actions for the repository.
4. Select **Build TAJIR Android APK**, choose **Run workflow**, then run it on `main`.
5. Wait for the run to finish with a green check. Open that run and download the `TAJIR-android-test-apk` artifact. Extract the downloaded artifact ZIP to get `app-debug.apk`.
6. Open `app-debug.apk` on the Android phone and allow installation from that source if Android asks.

## Important
- This is a debug-signed test APK, suitable for initial installation/testing. It is not a Play Store release build.
- The current Flutter app is still a starter frontend. It has not yet been connected to the live Supabase backend, and real authentication, role enforcement, complete accounting, customer self-service and verified M-Pesa callbacks are not ready. Do not enter real confidential business records or rely on it for live financial transactions yet.
- Do not put Supabase service-role keys, passwords, signing keystores or other secrets in the repository. A Supabase anon/public key is not a service-role key; backend security must still be enforced with RLS and trusted server functions.
- This build workflow does not apply database migrations or deploy backend services.
