package com.tajir.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
