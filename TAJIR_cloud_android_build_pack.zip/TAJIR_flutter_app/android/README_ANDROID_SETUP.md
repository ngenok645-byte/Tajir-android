# TAJIR Android project setup

Android application ID: `com.tajir.app`
Minimum Android: API 23 (Android 6.0)
Compile/target SDK: 35
Java/Kotlin target: 17
Gradle distribution: 8.7

## Build prerequisites
- Flutter stable SDK (compatible with Dart >=3.3)
- Android Studio with Android SDK Platform 35 and Build Tools
- Android SDK licenses accepted (`flutter doctor --android-licenses`)

## Build a test APK
From the project root:

```bash
flutter create . --platforms=android,web
flutter pub get
flutter doctor -v
flutter build apk --release \
  --dart-define=SUPABASE_URL=https://YOUR-PROJECT.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY
```

The output should be `build/app/outputs/flutter-apk/app-release.apk`.

## Important release note
The release build currently uses Android's debug signing config solely to permit internal test builds. Do not distribute this as a public production release. Generate and protect a private upload/release keystore, configure signing in `android/app/build.gradle`, and keep the keystore/passwords out of source control.

The Supabase URL and publishable/anon key are client configuration, not secrets. Never place a service-role key in the app. The backend must enforce all permissions with RLS and server-side functions.
