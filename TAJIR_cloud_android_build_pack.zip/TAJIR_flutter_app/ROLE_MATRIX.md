# TAJIR role matrix

| Capability | Director | Accountant | Worker | Customer |
|---|---:|---:|---:|---:|
| View buying prices / purchase costs | Yes | Yes | No | No |
| View gross profit / finance dashboards | Yes | Yes | No | No |
| Manage users and roles | Yes | No | No | No |
| Manage company settings | Yes | No | No | No |
| Submit purchase through controlled RPC | Yes | Yes | Yes | No |
| View purchase cost tables | Yes | Yes | No | No |
| Record sales and stock operations | Yes | Yes | Yes | No |
| View own orders/payments/credit | Yes | Finance scope | Operational scope | Own records |
| View audit log | Yes | No | No | No |

Workers submit purchase data through a security-definer transaction function. They do not receive SELECT access to purchase_items, purchase_expenses, stock_batches, stock_allocations, or finance views. The accountant has finance visibility but no user/role administration.
