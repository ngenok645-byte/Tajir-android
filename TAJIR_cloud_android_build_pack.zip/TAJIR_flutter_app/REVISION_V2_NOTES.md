# TAJIR database revision v2

This is a proposed security/accounting patch for the original core migration. It is **not yet applied** to Supabase and is not a production certification.

## Apply order
1. `supabase/migrations/202611080001_tajir_core.sql`
2. `supabase/migrations/202611090001_tajir_security_finance_v2.sql`
3. Run `supabase/tests_security_finance_v2.sql` as the database owner and review every result.

## Main changes
- Worker direct table access is reduced to operational columns; sensitive purchase unit costs, sale prices/totals, payment records, allocations and expense rows are not directly readable.
- Finance-only views explicitly check `can_view_finance()`.
- Purchase expenses are allocated to stock batches by each item's share of the purchase's base value. This makes FIFO COGS use landed cost rather than base unit price alone.
- Workers receive only a sale ID and status from the sale RPC, not totals or balances.
- Cash/bank receipts are treated as received; M-Pesa remains pending until trusted server-side confirmation. Pending M-Pesa is not posted as a credit repayment.
- Overpayments are rejected in the payment RPC; credit is represented as an unpaid balance, not a payment method transaction.
- Worker delivery updates are restricted to deliveries assigned to that worker.

## Still required before production
- SQL execution against a disposable Supabase project and complete PostgreSQL syntax validation.
- Authenticated integration tests for director, accountant, worker and customer roles, including attempts to query hidden columns and views.
- A trusted server-side M-Pesa Daraja callback that validates provider response/signature and calls `confirm_mpesa_payment`; this function is intentionally not executable by authenticated app clients.
- Customer-safe order/payment/credit views or RPCs before enabling customer self-service.
- Review purchase payload field mapping so all maize/fertilizer-specific fields are captured consistently; the `details` JSON object must not be sent back to worker clients.
- Reconcile rounding at cent level for allocations and add reversal/refund workflows before live accounting.
- Build and test the Android app separately. This SQL does not create an APK.
