# TAJIR Android + Web application source (starter)

This is a Flutter application source project. The same codebase can be built as an Android app and a responsive website. It uses the TAJIR Supabase backend starter in the separate `TAJIR_production_backend_starter.zip`.

## Included in this first frontend version
- TAJIR green-and-gold branding and login
- Dashboard and stock balance view
- Purchase entry for maize and fertilizer
- Sales/order entry with collection or delivery
- Payment recording fields for M-Pesa, cash, bank and credit
- Customer list
- Responsive navigation for phone and wide screens

## Important maturity / safety notice
This is an initial frontend starter, not a deployed or production-certified system. It has not been connected to your live Supabase project, built into an APK, or tested with live user accounts. Do not enter real confidential business information until the backend has been reviewed, configured, and tested. The SQL starter itself also needs the security and accounting review listed in its README.

## Requirements
- Flutter SDK (stable channel)
- Android Studio / Android SDK for Android builds
- Supabase project with the TAJIR SQL migration applied
- Supabase project URL and anon/public key

## Run locally
From this folder, first generate the standard Android and web platform folders (the source archive contains the shared Dart app and web entry point):

```bash
flutter create . --platforms=android,web
flutter pub get
flutter run --dart-define=SUPABASE_URL=https://YOUR-PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```

## Build Android APK

```bash
flutter build apk --release --dart-define=SUPABASE_URL=https://YOUR-PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```

APK output (after a successful build): `build/app/outputs/flutter-apk/app-release.apk`

## Build website

```bash
flutter build web --release --dart-define=SUPABASE_URL=https://YOUR-PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```

Deploy the contents of `build/web` to a static web host with HTTPS. Configure Supabase Auth redirect URLs for the deployed domain.

## First database setup
1. Create a Supabase project.
2. Apply `supabase/migrations/202611080001_tajir_core.sql` from the backend starter.
3. Configure authentication providers and redirect URLs.
4. Create initial auth users for Mercy and Edu using a trusted administrator process.
5. Provision matching `profiles` rows with `role='director'` using the SQL editor/service role. Never let a public signup choose a privileged role.
6. Create/confirm the `TAJIR Ntulele` branch and Maize/Fertilizer products. The migration seeds these on a fresh database.
7. Add staff/customer accounts and assign roles only through a trusted admin process.
8. Test each role with separate accounts before entering real transactions.

## Role protection
The app relies on backend Row Level Security and RPC permissions. Hiding a button in the app is not a security control. The current frontend intentionally does not expose profit dashboards or buying costs as worker-facing UI. Validate all permissions on the actual Supabase project before launch.

## Current limitations to address before launch
- Admin screens for users, roles, settings and full finance reports are not yet implemented.
- Customer self-service portal is not yet implemented.
- M-Pesa Daraja STK Push and verified callback integration are not implemented; current payment entry is only a record.
- Supplier/customer creation, expense entry, delivery assignment, receipt printing and audit-log UI remain to be built.
- The purchase form captures core quantity and unit cost; the full maize/fertilizer extra fields from your trading spreadsheet need dedicated fields and cost allocation.
- The backend migration and RPCs need review/fixes and end-to-end tests before production.

## Android project configuration
An Android project configuration is now included under `android/` with package ID `com.tajir.app`, Android API 23 minimum, API 35 target, Java 17, and Gradle 8.7. See `android/README_ANDROID_SETUP.md` for prerequisites and build instructions. This source archive is not itself an APK; it must be built with Flutter and the Android SDK.
