-- TAJIR core schema. Apply to a fresh Supabase project.
-- Monetary amounts are KES. Sensitive purchase costs are finance-only.

create extension if not exists pgcrypto;

create type public.tajir_role as enum ('director','accountant','worker','customer');
create type public.product_category as enum ('maize','fertilizer');
create type public.payment_method as enum ('mpesa','cash','bank','credit');
create type public.fulfilment_mode as enum ('collection','delivery');
create type public.order_status as enum ('draft','confirmed','preparing','ready','dispatched','collected','delivered','cancelled');
create type public.delivery_status as enum ('pending','assigned','in_transit','delivered','failed','cancelled');
create type public.stock_movement_type as enum ('purchase_in','sale_out','adjustment_in','adjustment_out','transfer_in','transfer_out','reversal');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete restrict,
  full_name text not null,
  phone text unique,
  role public.tajir_role not null default 'customer',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.branches (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  county text not null default 'Narok',
  town text not null default 'Ntulele',
  address text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(name, town, county)
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  sku text unique,
  name text not null,
  category public.product_category not null,
  unit text not null default 'bag',
  description text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.suppliers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  location text,
  notes text,
  created_at timestamptz not null default now()
);

create table public.customers (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid unique references public.profiles(id) on delete set null,
  name text not null,
  phone text,
  email text,
  default_address text,
  credit_limit numeric(14,2) not null default 0 check (credit_limit >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.purchases (
  id uuid primary key default gen_random_uuid(),
  purchase_no bigint generated always as identity unique,
  branch_id uuid not null references public.branches(id),
  supplier_id uuid references public.suppliers(id),
  purchase_date date not null default current_date,
  payer text check (payer is null or payer in ('Mercy','Edu','Company','Other')),
  reference text,
  notes text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  status text not null default 'posted' check (status in ('posted','reversed'))
);

create table public.purchase_items (
  id uuid primary key default gen_random_uuid(),
  purchase_id uuid not null references public.purchases(id) on delete restrict,
  product_id uuid not null references public.products(id),
  quantity numeric(14,3) not null check (quantity > 0),
  unit text not null,
  -- Flexible fields preserve TAJIR-specific entries such as broka, bag price,
  -- voucher price, hema, drying/loading and other purchase particulars.
  details jsonb not null default '{}'::jsonb,
  unit_cost numeric(14,2) not null check (unit_cost >= 0),
  line_cost numeric(16,2) generated always as (round(quantity * unit_cost,2)) stored
);

create table public.purchase_expenses (
  id uuid primary key default gen_random_uuid(),
  purchase_id uuid not null references public.purchases(id) on delete restrict,
  expense_type text not null,
  amount numeric(14,2) not null check (amount >= 0),
  description text,
  created_at timestamptz not null default now()
);

create table public.stock_batches (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id),
  branch_id uuid not null references public.branches(id),
  purchase_item_id uuid unique references public.purchase_items(id),
  received_at timestamptz not null default now(),
  quantity_received numeric(14,3) not null check (quantity_received > 0),
  quantity_remaining numeric(14,3) not null check (quantity_remaining >= 0),
  unit_cost numeric(14,2) not null check (unit_cost >= 0),
  check (quantity_remaining <= quantity_received)
);

create table public.stock_movements (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id),
  branch_id uuid not null references public.branches(id),
  batch_id uuid references public.stock_batches(id),
  movement_type public.stock_movement_type not null,
  quantity numeric(14,3) not null check (quantity > 0),
  source_table text,
  source_id uuid,
  notes text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.sales (
  id uuid primary key default gen_random_uuid(),
  sale_no bigint generated always as identity unique,
  branch_id uuid not null references public.branches(id),
  customer_id uuid references public.customers(id),
  sale_date date not null default current_date,
  status public.order_status not null default 'confirmed',
  fulfilment public.fulfilment_mode not null default 'collection',
  subtotal numeric(16,2) not null default 0,
  delivery_fee numeric(14,2) not null default 0 check (delivery_fee >= 0),
  total numeric(16,2) not null default 0,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.sale_items (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references public.sales(id) on delete restrict,
  product_id uuid not null references public.products(id),
  quantity numeric(14,3) not null check (quantity > 0),
  unit_price numeric(14,2) not null check (unit_price >= 0),
  line_total numeric(16,2) generated always as (round(quantity * unit_price,2)) stored
);

create table public.stock_allocations (
  id uuid primary key default gen_random_uuid(),
  sale_item_id uuid not null references public.sale_items(id),
  batch_id uuid not null references public.stock_batches(id),
  quantity numeric(14,3) not null check (quantity > 0),
  cost_at_sale numeric(14,2) not null check (cost_at_sale >= 0)
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references public.sales(id),
  customer_id uuid references public.customers(id),
  method public.payment_method not null,
  amount numeric(14,2) not null check (amount > 0),
  reference text,
  provider_verified boolean not null default false,
  paid_at timestamptz not null default now(),
  recorded_by uuid not null references public.profiles(id),
  status text not null default 'received' check (status in ('pending','received','reversed','failed'))
);

create table public.customer_credit_ledger (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.customers(id),
  sale_id uuid references public.sales(id),
  payment_id uuid references public.payments(id),
  entry_type text not null check (entry_type in ('credit_sale','repayment','adjustment','reversal')),
  amount numeric(14,2) not null check (amount > 0),
  notes text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.deliveries (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null unique references public.sales(id),
  destination text not null,
  delivery_fee numeric(14,2) not null default 0 check (delivery_fee >= 0),
  driver_id uuid references public.profiles(id),
  status public.delivery_status not null default 'pending',
  assigned_at timestamptz,
  delivered_at timestamptz,
  proof_reference text,
  notes text,
  created_at timestamptz not null default now()
);

create table public.operating_expenses (
  id uuid primary key default gen_random_uuid(),
  branch_id uuid not null references public.branches(id),
  expense_date date not null default current_date,
  expense_type text not null,
  amount numeric(14,2) not null check (amount >= 0),
  paid_by text check (paid_by is null or paid_by in ('Mercy','Edu','Company','Other')),
  reference text,
  description text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id),
  action text not null,
  entity_table text not null,
  entity_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index on public.purchases(branch_id, purchase_date);
create index on public.purchase_items(purchase_id);
create index on public.stock_batches(branch_id, product_id, received_at);
create index on public.stock_movements(branch_id, product_id, created_at);
create index on public.sales(branch_id, sale_date);
create index on public.payments(sale_id, paid_at);
create index on public.customer_credit_ledger(customer_id, created_at);
create index on public.deliveries(status, driver_id);

-- Helper functions: SECURITY DEFINER with fixed search_path to avoid search-path attacks.
create or replace function public.current_role()
returns public.tajir_role
language sql stable security definer
set search_path = public, pg_temp
as $$
  select role from public.profiles
  where id = auth.uid() and active = true
$$;

create or replace function public.is_director()
returns boolean language sql stable security definer
set search_path = public, pg_temp
as $$
  select coalesce(public.current_role() = 'director'::public.tajir_role, false)
$$;

create or replace function public.can_view_finance()
returns boolean language sql stable security definer
set search_path = public, pg_temp
as $$
  select coalesce(public.current_role() in ('director','accountant'), false)
$$;

create or replace function public.is_staff()
returns boolean language sql stable security definer
set search_path = public, pg_temp
as $$
  select coalesce(public.current_role() in ('director','accountant','worker'), false)
$$;

-- Prevent a user from changing their own role, active flag, or profile identity.
create or replace function public.protect_profile_changes()
returns trigger language plpgsql security definer
set search_path = public, pg_temp
as $$
begin
  if auth.uid() = old.id and not public.is_director() then
    if new.role is distinct from old.role or new.active is distinct from old.active or new.id is distinct from old.id then
      raise exception 'You cannot change protected account fields';
    end if;
  end if;
  if not public.is_director() and auth.uid() is not null and auth.uid() <> old.id then
    raise exception 'Only directors may administer profiles';
  end if;
  return new;
end;
$$;
create trigger profiles_protect before update on public.profiles
for each row execute function public.protect_profile_changes();

-- Generic audit trigger.
create or replace function public.write_audit_log()
returns trigger language plpgsql security definer
set search_path = public, pg_temp
as $$
declare rid uuid;
begin
  if tg_op = 'DELETE' then rid := old.id; else rid := new.id; end if;
  insert into public.audit_logs(actor_id, action, entity_table, entity_id)
  values (auth.uid(), tg_op, tg_table_name, rid);
  if tg_op = 'DELETE' then return old; else return new; end if;
end;
$$;
create trigger audit_purchases after insert or update or delete on public.purchases
for each row execute function public.write_audit_log();
create trigger audit_sales after insert or update or delete on public.sales
for each row execute function public.write_audit_log();
create trigger audit_payments after insert or update or delete on public.payments
for each row execute function public.write_audit_log();
create trigger audit_expenses after insert or update or delete on public.operating_expenses
for each row execute function public.write_audit_log();

-- RLS on every business table.
alter table public.profiles enable row level security;
alter table public.branches enable row level security;
alter table public.products enable row level security;
alter table public.suppliers enable row level security;
alter table public.customers enable row level security;
alter table public.purchases enable row level security;
alter table public.purchase_items enable row level security;
alter table public.purchase_expenses enable row level security;
alter table public.stock_batches enable row level security;
alter table public.stock_movements enable row level security;
alter table public.sales enable row level security;
alter table public.sale_items enable row level security;
alter table public.stock_allocations enable row level security;
alter table public.payments enable row level security;
alter table public.customer_credit_ledger enable row level security;
alter table public.deliveries enable row level security;
alter table public.operating_expenses enable row level security;
alter table public.audit_logs enable row level security;

-- Restrict direct table writes. Business mutations are via RPC functions below.
revoke all on all tables in schema public from anon, authenticated;
grant usage on schema public to authenticated;
grant select on public.profiles to authenticated;
grant select on public.branches, public.products to authenticated;
grant select on public.suppliers to authenticated;
grant select on public.customers to authenticated;
grant select on public.purchases, public.purchase_items, public.purchase_expenses to authenticated;
grant select on public.stock_batches, public.stock_movements to authenticated;
grant select on public.sales, public.sale_items, public.stock_allocations to authenticated;
grant select on public.payments, public.customer_credit_ledger, public.deliveries to authenticated;
grant select on public.operating_expenses, public.audit_logs to authenticated;

-- Profiles: users see themselves; directors see all; accountant sees staff profiles needed for finance.
create policy profile_self_or_director on public.profiles for select to authenticated
using (id = auth.uid() or public.is_director() or public.current_role() = 'accountant');

create policy branches_staff_read on public.branches for select to authenticated
using (public.is_staff());
create policy products_active_read on public.products for select to authenticated
using (active = true and auth.uid() is not null);
create policy suppliers_finance_read on public.suppliers for select to authenticated
using (public.can_view_finance() or public.is_director());
create policy customers_scoped_read on public.customers for select to authenticated
using (
  public.is_staff()
  or profile_id = auth.uid()
);

create policy purchases_finance_read on public.purchases for select to authenticated
using (public.can_view_finance());
create policy purchase_items_finance_read on public.purchase_items for select to authenticated
using (public.can_view_finance());
create policy purchase_expenses_finance_read on public.purchase_expenses for select to authenticated
using (public.can_view_finance());
create policy batches_finance_read on public.stock_batches for select to authenticated
using (public.can_view_finance());
create policy stock_movements_staff_read on public.stock_movements for select to authenticated
using (public.is_staff());
create policy sales_staff_or_customer_read on public.sales for select to authenticated
using (
  public.is_staff()
  or customer_id in (select c.id from public.customers c where c.profile_id = auth.uid())
);
create policy sale_items_staff_or_customer_read on public.sale_items for select to authenticated
using (
  public.is_staff()
  or sale_id in (
    select s.id from public.sales s
    join public.customers c on c.id = s.customer_id
    where c.profile_id = auth.uid()
  )
);
create policy allocations_finance_read on public.stock_allocations for select to authenticated
using (public.can_view_finance());
create policy payments_scoped_read on public.payments for select to authenticated
using (
  public.is_staff()
  or customer_id in (select c.id from public.customers c where c.profile_id = auth.uid())
);
create policy credit_scoped_read on public.customer_credit_ledger for select to authenticated
using (
  public.can_view_finance()
  or customer_id in (select c.id from public.customers c where c.profile_id = auth.uid())
);
create policy deliveries_staff_or_customer_read on public.deliveries for select to authenticated
using (
  public.is_staff()
  or sale_id in (
    select s.id from public.sales s
    join public.customers c on c.id = s.customer_id
    where c.profile_id = auth.uid()
  )
);
create policy expenses_finance_read on public.operating_expenses for select to authenticated
using (public.can_view_finance());
create policy audit_director_read on public.audit_logs for select to authenticated
using (public.is_director());

-- Operational stock function deliberately excludes batch IDs and costs.
-- SECURITY DEFINER is necessary because workers are not allowed to SELECT
-- confidential stock_batches; the function returns only aggregate quantities.
create or replace function public.get_stock_balances(p_branch_id uuid default null)
returns table(branch_id uuid, product_id uuid, product_name text,
              category public.product_category, unit text, quantity_available numeric)
language plpgsql stable security definer
set search_path = public, pg_temp
as $$
begin
  if not public.is_staff() then raise exception 'Not authorised'; end if;
  return query
    select b.branch_id, b.product_id, p.name, p.category, p.unit,
           sum(b.quantity_remaining)::numeric(14,3)
    from public.stock_batches b
    join public.products p on p.id=b.product_id
    where p_branch_id is null or b.branch_id=p_branch_id
    group by b.branch_id,b.product_id,p.name,p.category,p.unit;
end;
$$;
revoke all on function public.get_stock_balances(uuid) from public, anon;
grant execute on function public.get_stock_balances(uuid) to authenticated;

-- Finance views: underlying tables already have RLS; explicit view policies are not a substitute.
create or replace view public.finance_purchase_detail
with (security_invoker = true)
as
select pu.id purchase_id, pu.purchase_no, pu.purchase_date, pu.payer,
       pr.name product_name, pi.quantity, pi.unit, pi.details,
       pi.unit_cost, pi.line_cost, pu.branch_id
from public.purchases pu
join public.purchase_items pi on pi.purchase_id = pu.id
join public.products pr on pr.id = pi.product_id;

create or replace view public.finance_stock_valuation
with (security_invoker = true)
as
select branch_id, product_id, sum(quantity_remaining) quantity_remaining,
       sum(quantity_remaining * unit_cost)::numeric(16,2) stock_value
from public.stock_batches
group by branch_id, product_id;

create or replace view public.finance_sales_summary
with (security_invoker = true)
as
select s.branch_id, date_trunc('month', s.sale_date)::date month,
       count(distinct s.id) sales_count, sum(s.total)::numeric(16,2) sales_revenue
from public.sales s
where s.status <> 'cancelled'
group by s.branch_id, date_trunc('month', s.sale_date)::date;

create or replace view public.finance_profit_summary
with (security_invoker = true)
as
select s.branch_id, date_trunc('month', s.sale_date)::date month,
       sum(s.total)::numeric(16,2) revenue,
       sum(coalesce(cogs.cost,0))::numeric(16,2) cost_of_goods_sold,
       (sum(s.total)-sum(coalesce(cogs.cost,0)))::numeric(16,2) gross_profit
from public.sales s
left join (
  select si.sale_id, sum(sa.quantity * sa.cost_at_sale)::numeric(16,2) cost
  from public.sale_items si
  join public.stock_allocations sa on sa.sale_item_id = si.id
  group by si.sale_id
) cogs on cogs.sale_id = s.id
where s.status <> 'cancelled'
group by s.branch_id, date_trunc('month', s.sale_date)::date;

create or replace view public.finance_credit_summary
with (security_invoker = true)
as
select c.id customer_id, c.name, c.phone,
       coalesce(sum(case when l.entry_type in ('credit_sale','adjustment') then l.amount
                         when l.entry_type in ('repayment','reversal') then -l.amount else 0 end),0)::numeric(16,2) balance
from public.customers c
left join public.customer_credit_ledger l on l.customer_id = c.id
group by c.id, c.name, c.phone;

grant select on public.finance_purchase_detail, public.finance_stock_valuation,
 public.finance_sales_summary, public.finance_profit_summary, public.finance_credit_summary to authenticated;

-- Transactional purchase RPC. Worker can submit cost but receives only ID and quantities.
create or replace function public.record_purchase(p_payload jsonb)
returns jsonb language plpgsql security definer
set search_path = public, pg_temp
as $$
declare
  v_role public.tajir_role := public.current_role();
  v_purchase_id uuid;
  v_branch uuid := (p_payload->>'branch_id')::uuid;
  v_supplier uuid := nullif(p_payload->>'supplier_id','')::uuid;
  v_item jsonb;
  v_exp jsonb;
  v_product uuid;
  v_qty numeric(14,3);
  v_cost numeric(14,2);
  v_unit text;
  v_item_id uuid;
  v_total_qty numeric(14,3) := 0;
begin
  if v_role not in ('director','accountant','worker') then raise exception 'Not authorised'; end if;
  if jsonb_typeof(p_payload->'items') <> 'array' or jsonb_array_length(p_payload->'items') = 0 then
    raise exception 'At least one purchase item is required';
  end if;
  if not exists(select 1 from public.branches where id=v_branch and active) then raise exception 'Invalid branch'; end if;

  insert into public.purchases(branch_id,supplier_id,purchase_date,payer,reference,notes,created_by)
  values(v_branch,v_supplier,coalesce((p_payload->>'purchase_date')::date,current_date),
    nullif(p_payload->>'payer',''),nullif(p_payload->>'reference',''),
    nullif(p_payload->>'notes',''),auth.uid())
  returning id into v_purchase_id;

  for v_item in select value from jsonb_array_elements(p_payload->'items') loop
    v_product := (v_item->>'product_id')::uuid;
    v_qty := (v_item->>'quantity')::numeric;
    v_cost := (v_item->>'unit_cost')::numeric;
    v_unit := coalesce(nullif(v_item->>'unit',''), 'bag');
    if v_qty <= 0 or v_cost < 0 then raise exception 'Invalid quantity or cost'; end if;
    if not exists(select 1 from public.products where id=v_product and active) then raise exception 'Invalid product'; end if;

    insert into public.purchase_items(purchase_id,product_id,quantity,unit,details,unit_cost)
    values(v_purchase_id,v_product,v_qty,v_unit,coalesce(v_item->'details','{}'::jsonb),v_cost)
    returning id into v_item_id;

    insert into public.stock_batches(product_id,branch_id,purchase_item_id,quantity_received,quantity_remaining,unit_cost)
    values(v_product,v_branch,v_item_id,v_qty,v_qty,v_cost);

    insert into public.stock_movements(product_id,branch_id,movement_type,quantity,source_table,source_id,created_by)
    values(v_product,v_branch,'purchase_in',v_qty,'purchases',v_purchase_id,auth.uid());
    v_total_qty := v_total_qty + v_qty;
  end loop;

  if jsonb_typeof(p_payload->'expenses') = 'array' then
    for v_exp in select value from jsonb_array_elements(p_payload->'expenses') loop
      insert into public.purchase_expenses(purchase_id,expense_type,amount,description)
      values(v_purchase_id,v_exp->>'expense_type',(v_exp->>'amount')::numeric,nullif(v_exp->>'description',''));
    end loop;
  end if;

  return jsonb_build_object('purchase_id',v_purchase_id,'accepted_quantity',v_total_qty,'status','posted');
end;
$$;

-- Transactional sale RPC; FIFO allocation. Does not return COGS or profit to workers.
create or replace function public.record_sale(p_payload jsonb)
returns jsonb language plpgsql security definer
set search_path = public, pg_temp
as $$
declare
  v_role public.tajir_role := public.current_role();
  v_sale_id uuid;
  v_branch uuid := (p_payload->>'branch_id')::uuid;
  v_customer uuid := nullif(p_payload->>'customer_id','')::uuid;
  v_mode public.fulfilment_mode := (p_payload->>'fulfilment_mode')::public.fulfilment_mode;
  v_item jsonb;
  v_product uuid;
  v_qty numeric(14,3);
  v_price numeric(14,2);
  v_remaining numeric(14,3);
  v_take numeric(14,3);
  v_batch record;
  v_sale_item uuid;
  v_subtotal numeric(16,2) := 0;
  v_fee numeric(14,2) := coalesce((p_payload->>'delivery_fee')::numeric,0);
  v_total numeric(16,2);
  v_paid numeric(14,2) := 0;
  v_balance numeric(16,2);
  v_payment jsonb := p_payload->'payment';
  v_payment_id uuid;
begin
  if v_role not in ('director','accountant','worker') then raise exception 'Not authorised'; end if;
  if jsonb_typeof(p_payload->'items') <> 'array' or jsonb_array_length(p_payload->'items')=0 then raise exception 'Sale items required'; end if;
  if v_mode='delivery' and nullif(p_payload->>'delivery_address','') is null then raise exception 'Delivery address required'; end if;
  if v_mode='collection' then v_fee := 0; end if;

  insert into public.sales(branch_id,customer_id,sale_date,fulfilment,delivery_fee,created_by)
  values(v_branch,v_customer,coalesce((p_payload->>'sale_date')::date,current_date),v_mode,v_fee,auth.uid())
  returning id into v_sale_id;

  for v_item in select value from jsonb_array_elements(p_payload->'items') loop
    v_product := (v_item->>'product_id')::uuid;
    v_qty := (v_item->>'quantity')::numeric;
    v_price := (v_item->>'unit_price')::numeric;
    if v_qty <= 0 or v_price < 0 then raise exception 'Invalid sale quantity or price'; end if;
    insert into public.sale_items(sale_id,product_id,quantity,unit_price)
    values(v_sale_id,v_product,v_qty,v_price) returning id into v_sale_item;
    v_subtotal := v_subtotal + round(v_qty*v_price,2);
    v_remaining := v_qty;

    for v_batch in
      select * from public.stock_batches
      where branch_id=v_branch and product_id=v_product and quantity_remaining>0
      order by received_at,id
      for update
    loop
      exit when v_remaining <= 0;
      v_take := least(v_remaining,v_batch.quantity_remaining);
      update public.stock_batches set quantity_remaining=quantity_remaining-v_take where id=v_batch.id;
      insert into public.stock_allocations(sale_item_id,batch_id,quantity,cost_at_sale)
      values(v_sale_item,v_batch.id,v_take,v_batch.unit_cost);
      insert into public.stock_movements(product_id,branch_id,batch_id,movement_type,quantity,source_table,source_id,created_by)
      values(v_product,v_branch,v_batch.id,'sale_out',v_take,'sales',v_sale_id,auth.uid());
      v_remaining := v_remaining-v_take;
    end loop;
    if v_remaining > 0 then raise exception 'Insufficient stock for product %',v_product; end if;
  end loop;

  v_total := v_subtotal + v_fee;
  update public.sales set subtotal=v_subtotal,total=v_total where id=v_sale_id;

  if v_mode='delivery' then
    insert into public.deliveries(sale_id,destination,delivery_fee)
    values(v_sale_id,p_payload->>'delivery_address',v_fee);
  else
    update public.sales set status='ready' where id=v_sale_id;
  end if;

  if v_payment is not null and jsonb_typeof(v_payment)='object' then
    v_paid := coalesce((v_payment->>'amount')::numeric,0);
    if v_paid > 0 then
      insert into public.payments(sale_id,customer_id,method,amount,reference,provider_verified,recorded_by)
      values(v_sale_id,v_customer,(v_payment->>'method')::public.payment_method,v_paid,
        nullif(v_payment->>'reference',''),false,auth.uid()) returning id into v_payment_id;
      if (v_payment->>'method') <> 'credit' and v_customer is not null then
        insert into public.customer_credit_ledger(customer_id,sale_id,payment_id,entry_type,amount,created_by)
        values(v_customer,v_sale_id,v_payment_id,'repayment',v_paid,auth.uid());
      end if;
    end if;
  end if;

  v_balance := greatest(v_total-v_paid,0);
  if v_balance > 0 and v_customer is not null then
    insert into public.customer_credit_ledger(customer_id,sale_id,entry_type,amount,created_by)
    values(v_customer,v_sale_id,'credit_sale',v_balance,auth.uid());
  end if;

  if v_role='worker' then
    return jsonb_build_object('sale_id',v_sale_id,'subtotal',v_subtotal,'delivery_fee',v_fee,'total',v_total,'paid',v_paid,'balance',v_balance);
  else
    return jsonb_build_object('sale_id',v_sale_id,'subtotal',v_subtotal,'delivery_fee',v_fee,'total',v_total,'paid',v_paid,'balance',v_balance);
  end if;
end;
$$;

create or replace function public.record_payment(p_payload jsonb)
returns jsonb language plpgsql security definer
set search_path = public, pg_temp
as $$
declare
  v_role public.tajir_role := public.current_role();
  v_sale uuid := (p_payload->>'sale_id')::uuid;
  v_customer uuid;
  v_amount numeric(14,2) := (p_payload->>'amount')::numeric;
  v_payment uuid;
begin
  if v_role not in ('director','accountant','worker') then raise exception 'Not authorised'; end if;
  if v_amount <= 0 then raise exception 'Payment must be positive'; end if;
  select customer_id into v_customer from public.sales where id=v_sale;
  if not found then raise exception 'Sale not found'; end if;
  insert into public.payments(sale_id,customer_id,method,amount,reference,provider_verified,recorded_by)
  values(v_sale,v_customer,(p_payload->>'method')::public.payment_method,v_amount,
    nullif(p_payload->>'reference',''),false,auth.uid())
  returning id into v_payment;
  if v_customer is not null then
    insert into public.customer_credit_ledger(customer_id,sale_id,payment_id,entry_type,amount,created_by)
    values(v_customer,v_sale,v_payment,'repayment',v_amount,auth.uid());
  end if;
  return jsonb_build_object('payment_id',v_payment,'status','recorded_pending_verification');
end;
$$;

create or replace function public.update_delivery_status(p_delivery_id uuid,p_status text,p_proof text default null)
returns jsonb language plpgsql security definer
set search_path = public, pg_temp
as $$
declare v_role public.tajir_role := public.current_role();
begin
  if v_role not in ('director','accountant','worker') then raise exception 'Not authorised'; end if;
  if p_status not in ('pending','assigned','in_transit','delivered','failed','cancelled') then raise exception 'Invalid delivery status'; end if;
  update public.deliveries
  set status=p_status, proof_reference=coalesce(p_proof,proof_reference),
      delivered_at=case when p_status='delivered' then now() else delivered_at end
  where id=p_delivery_id;
  if not found then raise exception 'Delivery not found'; end if;
  return jsonb_build_object('delivery_id',p_delivery_id,'status',p_status);
end;
$$;

-- Only authenticated staff can call business RPCs. No direct table DML is granted.
revoke all on function public.record_purchase(jsonb) from public, anon;
revoke all on function public.record_sale(jsonb) from public, anon;
revoke all on function public.record_payment(jsonb) from public, anon;
revoke all on function public.update_delivery_status(uuid,text,text) from public, anon;
grant execute on function public.record_purchase(jsonb) to authenticated;
grant execute on function public.record_sale(jsonb) to authenticated;
grant execute on function public.record_payment(jsonb) to authenticated;
grant execute on function public.update_delivery_status(uuid,text,text) to authenticated;

-- Additional customer own-record constraints: customers cannot use staff RPCs due role checks.
-- Seed Ntulele branch and catalogue.
insert into public.branches(name,county,town,address)
values ('TAJIR Ntulele','Narok','Ntulele','Ntulele, Kenya')
on conflict(name,town,county) do nothing;

insert into public.products(sku,name,category,unit)
values ('MAIZE-BAG','Maize','maize','bag'),
       ('FERT-BAG','Fertilizer','fertilizer','bag')
on conflict(sku) do nothing;
