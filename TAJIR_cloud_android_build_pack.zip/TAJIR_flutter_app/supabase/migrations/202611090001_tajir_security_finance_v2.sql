-- TAJIR security and accounting revision v2
-- Apply AFTER 202611080001_tajir_core.sql on a fresh project.

-- Replace broad SELECT grants with safe column grants. Workers may see operational
-- quantities and order state, but not purchase costs, sale prices, payment amounts,
-- credit balances, or profit. Finance data is accessed through finance-only views/RPCs.
revoke select on public.purchases, public.purchase_items, public.purchase_expenses,
  public.stock_batches, public.sales, public.sale_items, public.stock_allocations,
  public.payments, public.customer_credit_ledger, public.operating_expenses
  from authenticated;

-- Operational columns only. No cost/price/financial columns are granted here.
grant select (id, purchase_no, branch_id, purchase_date, payer, reference, notes, created_by, created_at, status)
  on public.purchases to authenticated;
grant select (id, purchase_id, product_id, quantity, unit)
  on public.purchase_items to authenticated;
grant select (id, product_id, branch_id, received_at, quantity_received, quantity_remaining)
  on public.stock_batches to authenticated;
grant select (id, sale_no, branch_id, customer_id, sale_date, status, fulfilment, created_by, created_at)
  on public.sales to authenticated;
grant select (id, sale_id, product_id, quantity)
  on public.sale_items to authenticated;
grant select (id, sale_id, destination, driver_id, status, assigned_at, delivered_at, proof_reference, notes, created_at)
  on public.deliveries to authenticated;

-- Finance roles receive sensitive data via separate, RLS-protected views.
-- Remove the old permissive policies and create role-specific policies.
drop policy if exists purchases_finance_read on public.purchases;
drop policy if exists purchase_items_finance_read on public.purchase_items;
drop policy if exists purchase_expenses_finance_read on public.purchase_expenses;
drop policy if exists batches_finance_read on public.stock_batches;
drop policy if exists sales_staff_or_customer_read on public.sales;
drop policy if exists sale_items_staff_or_customer_read on public.sale_items;
drop policy if exists payments_scoped_read on public.payments;
drop policy if exists credit_scoped_read on public.customer_credit_ledger;
drop policy if exists allocations_finance_read on public.stock_allocations;
drop policy if exists expenses_finance_read on public.operating_expenses;

create policy purchases_staff_operational_read on public.purchases for select to authenticated
  using (public.is_staff());
create policy purchase_items_staff_operational_read on public.purchase_items for select to authenticated
  using (public.is_staff());
create policy purchase_expenses_finance_read_v2 on public.purchase_expenses for select to authenticated
  using (public.can_view_finance());
create policy batches_staff_operational_read on public.stock_batches for select to authenticated
  using (public.is_staff());
create policy sales_staff_or_customer_read_v2 on public.sales for select to authenticated
  using (public.is_staff() or customer_id in (select c.id from public.customers c where c.profile_id=auth.uid()));
create policy sale_items_staff_or_customer_read_v2 on public.sale_items for select to authenticated
  using (public.is_staff() or sale_id in (select s.id from public.sales s join public.customers c on c.id=s.customer_id where c.profile_id=auth.uid()));
create policy allocations_finance_read_v2 on public.stock_allocations for select to authenticated
  using (public.can_view_finance());
create policy payments_finance_read_v2 on public.payments for select to authenticated
  using (public.can_view_finance());
create policy credit_finance_or_owner_read_v2 on public.customer_credit_ledger for select to authenticated
  using (public.can_view_finance() or customer_id in (select c.id from public.customers c where c.profile_id=auth.uid()));
create policy expenses_finance_read_v2 on public.operating_expenses for select to authenticated
  using (public.can_view_finance());

-- Financial views use invoker security so table grants and RLS still apply.
drop view if exists public.finance_purchase_detail;
create view public.finance_purchase_detail as
select pu.id purchase_id, pu.purchase_no, pu.purchase_date, pu.payer, pu.branch_id,
       pr.name product_name, pi.quantity, pi.unit, pi.details, pi.unit_cost base_unit_cost,
       pi.line_cost base_line_cost,
       coalesce(exp.total_expenses,0)::numeric(16,2) total_purchase_expenses,
       sb.unit_cost landed_unit_cost
from public.purchases pu
join public.purchase_items pi on pi.purchase_id=pu.id
join public.products pr on pr.id=pi.product_id
left join lateral (select sum(pe.amount) total_expenses from public.purchase_expenses pe where pe.purchase_id=pu.id) exp on true
left join public.stock_batches sb on sb.purchase_item_id=pi.id
where public.can_view_finance();

create or replace view public.finance_profit_summary as
select s.branch_id, date_trunc('month',s.sale_date)::date month,
       sum(s.total)::numeric(16,2) revenue,
       sum(coalesce(cogs.cost,0))::numeric(16,2) cost_of_goods_sold,
       sum(s.total)-sum(coalesce(cogs.cost,0)) gross_profit
from public.sales s
left join (select si.sale_id,sum(sa.quantity*sa.cost_at_sale)::numeric(16,2) cost
           from public.sale_items si join public.stock_allocations sa on sa.sale_item_id=si.id group by si.sale_id) cogs
  on cogs.sale_id=s.id
where s.status not in ('cancelled')
group by s.branch_id,date_trunc('month',s.sale_date)::date
having public.can_view_finance();

-- Purchase costs include landed expenses (transport, labour, drying, loading, broka,
-- bag price adjustments, hema, voucher, food/accommodation, etc.) allocated by base line value.
create or replace function public.record_purchase(p_payload jsonb)
returns jsonb language plpgsql security definer set search_path=public,pg_temp as $$
declare
  v_role public.tajir_role := public.current_role(); v_purchase uuid;
  v_branch uuid := (p_payload->>'branch_id')::uuid; v_item jsonb; v_exp jsonb;
  v_product uuid; v_qty numeric(14,3); v_cost numeric(14,2); v_unit text;
  v_item_id uuid; v_qty_total numeric(14,3):=0; v_base_total numeric(16,2):=0;
  v_exp_total numeric(16,2):=0;
begin
  if v_role not in ('director','accountant','worker') then raise exception 'Not authorised'; end if;
  if jsonb_typeof(p_payload->'items') is distinct from 'array' or jsonb_array_length(p_payload->'items')=0 then raise exception 'At least one purchase item is required'; end if;
  if not exists(select 1 from public.branches where id=v_branch and active) then raise exception 'Invalid branch'; end if;
  insert into public.purchases(branch_id,supplier_id,purchase_date,payer,reference,notes,created_by)
  values(v_branch,nullif(p_payload->>'supplier_id','')::uuid,coalesce((p_payload->>'purchase_date')::date,current_date),
         nullif(p_payload->>'payer',''),nullif(p_payload->>'reference',''),nullif(p_payload->>'notes',''),auth.uid())
  returning id into v_purchase;
  for v_item in select value from jsonb_array_elements(p_payload->'items') loop
    v_product:=(v_item->>'product_id')::uuid; v_qty:=(v_item->>'quantity')::numeric;
    v_cost:=(v_item->>'unit_cost')::numeric; v_unit:=coalesce(nullif(v_item->>'unit',''),'bag');
    if v_qty<=0 or v_cost<0 then raise exception 'Invalid quantity or unit cost'; end if;
    if not exists(select 1 from public.products where id=v_product and active) then raise exception 'Invalid product'; end if;
    insert into public.purchase_items(purchase_id,product_id,quantity,unit,details,unit_cost)
    values(v_purchase,v_product,v_qty,v_unit,coalesce(v_item->'details','{}'::jsonb),v_cost)
    returning id into v_item_id;
    v_qty_total:=v_qty_total+v_qty; v_base_total:=v_base_total+round(v_qty*v_cost,2);
  end loop;
  if jsonb_typeof(p_payload->'expenses')='array' then
    for v_exp in select value from jsonb_array_elements(p_payload->'expenses') loop
      if coalesce((v_exp->>'amount')::numeric,0)<0 then raise exception 'Expense cannot be negative'; end if;
      insert into public.purchase_expenses(purchase_id,expense_type,amount,description)
      values(v_purchase,coalesce(nullif(v_exp->>'expense_type',''),'other'),(v_exp->>'amount')::numeric,nullif(v_exp->>'description',''));
      v_exp_total:=v_exp_total+(v_exp->>'amount')::numeric;
    end loop;
  end if;
  -- Each stock batch receives its share of the purchase expenses, weighted by item cost.
  insert into public.stock_batches(product_id,branch_id,purchase_item_id,quantity_received,quantity_remaining,unit_cost)
  select pi.product_id,v_branch,pi.id,pi.quantity,pi.quantity,
         case when v_base_total>0 then round(pi.unit_cost + ((pi.line_cost/v_base_total)*v_exp_total/pi.quantity),2)
              else round(pi.unit_cost + (v_exp_total/nullif(v_qty_total,0)),2) end
  from public.purchase_items pi where pi.purchase_id=v_purchase;
  insert into public.stock_movements(product_id,branch_id,batch_id,movement_type,quantity,source_table,source_id,created_by)
  select sb.product_id,v_branch,sb.id,'purchase_in',sb.quantity_received,'purchases',v_purchase,auth.uid()
  from public.stock_batches sb where sb.purchase_item_id in (select id from public.purchase_items where purchase_id=v_purchase);
  return jsonb_build_object('purchase_id',v_purchase,'accepted_quantity',v_qty_total,'status','posted');
end; $$;

-- Sales: cash/bank payments are entered as received; M-Pesa remains pending until
-- a trusted Daraja callback verifies it. Credit ledger only counts confirmed money.
create or replace function public.record_sale(p_payload jsonb)
returns jsonb language plpgsql security definer set search_path=public,pg_temp as $$
declare
  v_role public.tajir_role:=public.current_role(); v_sale uuid;
  v_branch uuid:=(p_payload->>'branch_id')::uuid; v_customer uuid:=nullif(p_payload->>'customer_id','')::uuid;
  v_mode public.fulfilment_mode:=coalesce((p_payload->>'fulfilment_mode')::public.fulfilment_mode,'collection');
  v_item jsonb; v_product uuid; v_qty numeric(14,3); v_price numeric(14,2); v_remaining numeric(14,3); v_take numeric(14,3);
  v_batch record; v_sale_item uuid; v_subtotal numeric(16,2):=0; v_fee numeric(14,2):=coalesce((p_payload->>'delivery_fee')::numeric,0);
  v_total numeric(16,2); v_paid numeric(14,2):=0; v_balance numeric(16,2); v_method public.payment_method;
  v_payment jsonb:=p_payload->'payment'; v_payment_id uuid;
begin
  if v_role not in ('director','accountant','worker') then raise exception 'Not authorised'; end if;
  if jsonb_typeof(p_payload->'items') is distinct from 'array' or jsonb_array_length(p_payload->'items')=0 then raise exception 'Sale items required'; end if;
  if not exists(select 1 from public.branches where id=v_branch and active) then raise exception 'Invalid branch'; end if;
  if v_mode='delivery' and nullif(p_payload->>'delivery_address','') is null then raise exception 'Delivery address required'; end if;
  if v_mode='collection' then v_fee:=0; end if;
  if v_fee<0 then raise exception 'Delivery fee cannot be negative'; end if;
  insert into public.sales(branch_id,customer_id,sale_date,fulfilment,delivery_fee,created_by)
  values(v_branch,v_customer,coalesce((p_payload->>'sale_date')::date,current_date),v_mode,v_fee,auth.uid()) returning id into v_sale;
  for v_item in select value from jsonb_array_elements(p_payload->'items') loop
    v_product:=(v_item->>'product_id')::uuid; v_qty:=(v_item->>'quantity')::numeric; v_price:=(v_item->>'unit_price')::numeric;
    if v_qty<=0 or v_price<0 then raise exception 'Invalid sale quantity or price'; end if;
    if not exists(select 1 from public.products where id=v_product and active) then raise exception 'Invalid product'; end if;
    insert into public.sale_items(sale_id,product_id,quantity,unit_price) values(v_sale,v_product,v_qty,v_price) returning id into v_sale_item;
    v_subtotal:=v_subtotal+round(v_qty*v_price,2); v_remaining:=v_qty;
    for v_batch in select * from public.stock_batches where branch_id=v_branch and product_id=v_product and quantity_remaining>0 order by received_at,id for update loop
      exit when v_remaining<=0; v_take:=least(v_remaining,v_batch.quantity_remaining);
      update public.stock_batches set quantity_remaining=quantity_remaining-v_take where id=v_batch.id;
      insert into public.stock_allocations(sale_item_id,batch_id,quantity,cost_at_sale) values(v_sale_item,v_batch.id,v_take,v_batch.unit_cost);
      insert into public.stock_movements(product_id,branch_id,batch_id,movement_type,quantity,source_table,source_id,created_by)
      values(v_product,v_branch,v_batch.id,'sale_out',v_take,'sales',v_sale,auth.uid()); v_remaining:=v_remaining-v_take;
    end loop;
    if v_remaining>0 then raise exception 'Insufficient stock for product %',v_product; end if;
  end loop;
  v_total:=v_subtotal+v_fee; update public.sales set subtotal=v_subtotal,total=v_total where id=v_sale;
  if v_mode='delivery' then insert into public.deliveries(sale_id,destination,delivery_fee) values(v_sale,p_payload->>'delivery_address',v_fee);
  else update public.sales set status='ready' where id=v_sale; end if;
  if v_payment is not null and jsonb_typeof(v_payment)='object' then
    v_paid:=coalesce((v_payment->>'amount')::numeric,0); v_method:=(v_payment->>'method')::public.payment_method;
    if v_method='credit' and v_paid>0 then raise exception 'Credit is an unpaid balance, not a payment'; end if;
    if v_paid<0 or v_paid>v_total then raise exception 'Payment must be between zero and sale total'; end if;
    if v_paid>0 and v_method<>'credit' then
      insert into public.payments(sale_id,customer_id,method,amount,reference,provider_verified,status,recorded_by)
      values(v_sale,v_customer,v_method,v_paid,nullif(v_payment->>'reference',''),
             v_method in ('cash','bank'),case when v_method='mpesa' then 'pending' else 'received' end,auth.uid())
      returning id into v_payment_id;
      if v_customer is not null and v_method in ('cash','bank') then
        insert into public.customer_credit_ledger(customer_id,sale_id,payment_id,entry_type,amount,created_by)
        values(v_customer,v_sale,v_payment_id,'repayment',v_paid,auth.uid());
      end if;
      if v_method in ('credit','mpesa') then v_paid:=0; end if;
    end if;
  end if;
  v_balance:=greatest(v_total-v_paid,0);
  if v_balance>0 and v_customer is not null then
    insert into public.customer_credit_ledger(customer_id,sale_id,entry_type,amount,created_by)
    values(v_customer,v_sale,'credit_sale',v_balance,auth.uid());
  end if;
  if v_role='worker' then return jsonb_build_object('sale_id',v_sale,'status','recorded'); end if;
  return jsonb_build_object('sale_id',v_sale,'subtotal',v_subtotal,'delivery_fee',v_fee,'total',v_total,'confirmed_paid',v_paid,'outstanding_balance',v_balance);
end; $$;

create or replace function public.record_payment(p_payload jsonb)
returns jsonb language plpgsql security definer set search_path=public,pg_temp as $$
declare
  v_role public.tajir_role:=public.current_role(); v_sale uuid:=(p_payload->>'sale_id')::uuid;
  v_customer uuid; v_amount numeric(14,2):=(p_payload->>'amount')::numeric;
  v_method public.payment_method:=(p_payload->>'method')::public.payment_method; v_payment uuid;
  v_total numeric(16,2); v_confirmed numeric(16,2);
begin
  if v_role not in ('director','accountant','worker') then raise exception 'Not authorised'; end if;
  if v_amount<=0 then raise exception 'Payment must be positive'; end if;
  if v_method='credit' then raise exception 'Credit is an unpaid balance, not a payment'; end if;
  select customer_id,total into v_customer,v_total from public.sales where id=v_sale for update;
  if not found then raise exception 'Sale not found'; end if;
  select coalesce(sum(amount),0) into v_confirmed from public.payments where sale_id=v_sale and status='received' and (method<>'mpesa' or provider_verified);
  if v_confirmed+v_amount>v_total then raise exception 'Payment exceeds outstanding sale balance'; end if;
  insert into public.payments(sale_id,customer_id,method,amount,reference,provider_verified,status,recorded_by)
  values(v_sale,v_customer,v_method,v_amount,nullif(p_payload->>'reference',''),v_method in ('cash','bank'),
         case when v_method='mpesa' then 'pending' else 'received' end,auth.uid()) returning id into v_payment;
  if v_customer is not null and v_method in ('cash','bank') then
    insert into public.customer_credit_ledger(customer_id,sale_id,payment_id,entry_type,amount,created_by)
    values(v_customer,v_sale,v_payment,'repayment',v_amount,auth.uid());
  end if;
  if v_role='worker' then return jsonb_build_object('payment_id',v_payment,'status',case when v_method='mpesa' then 'pending_verification' else 'received' end); end if;
  return jsonb_build_object('payment_id',v_payment,'status',case when v_method='mpesa' then 'pending_verification' else 'received' end,'amount',v_amount);
end; $$;

-- Trusted backend only: call after validating the Daraja callback signature/result.
-- Not granted to authenticated clients; service role/backend integration must invoke it.
create or replace function public.confirm_mpesa_payment(p_payment_id uuid,p_provider_reference text)
returns jsonb language plpgsql security definer set search_path=public,pg_temp as $$
declare v_pay public.payments%rowtype; v_sale_total numeric(16,2); v_confirmed numeric(16,2);
begin
  select * into v_pay from public.payments where id=p_payment_id for update;
  if not found then raise exception 'Payment not found'; end if;
  if v_pay.method<>'mpesa' then raise exception 'Only M-Pesa payments can be confirmed here'; end if;
  if v_pay.status='received' and v_pay.provider_verified then return jsonb_build_object('payment_id',p_payment_id,'status','already_confirmed'); end if;
  if v_pay.status<>'pending' then raise exception 'Payment is not pending'; end if;
  select total into v_sale_total from public.sales where id=v_pay.sale_id for update;
  select coalesce(sum(amount),0) into v_confirmed from public.payments
    where sale_id=v_pay.sale_id and id<>p_payment_id and status='received';
  if v_confirmed+v_pay.amount>v_sale_total then
    update public.payments set status='failed' where id=p_payment_id;
    raise exception 'Confirmation would exceed sale balance';
  end if;
  update public.payments set provider_verified=true,status='received',reference=coalesce(nullif(p_provider_reference,''),reference) where id=p_payment_id;
  if v_pay.customer_id is not null then
    insert into public.customer_credit_ledger(customer_id,sale_id,payment_id,entry_type,amount,created_by)
    values(v_pay.customer_id,v_pay.sale_id,p_payment_id,'repayment',v_pay.amount,v_pay.recorded_by);
  end if;
  return jsonb_build_object('payment_id',p_payment_id,'status','confirmed');
end; $$;

-- Worker delivery updates are restricted to assigned deliveries. Directors/accountants
-- can manage all deliveries. Workers cannot assign drivers or cancel deliveries.
create or replace function public.update_delivery_status(p_delivery_id uuid,p_status text,p_proof text default null)
returns jsonb language plpgsql security definer set search_path=public,pg_temp as $$
declare v_role public.tajir_role:=public.current_role(); v_driver uuid;
begin
  if v_role not in ('director','accountant','worker') then raise exception 'Not authorised'; end if;
  if p_status not in ('in_transit','delivered','failed') then raise exception 'Invalid worker delivery status'; end if;
  select driver_id into v_driver from public.deliveries where id=p_delivery_id for update;
  if not found then raise exception 'Delivery not found'; end if;
  if v_role='worker' and v_driver is distinct from auth.uid() then raise exception 'Delivery is not assigned to this worker'; end if;
  update public.deliveries set status=p_status,proof_reference=coalesce(p_proof,proof_reference),
    delivered_at=case when p_status='delivered' then now() else delivered_at end where id=p_delivery_id;
  return jsonb_build_object('delivery_id',p_delivery_id,'status',p_status);
end; $$;

-- Lock down function execution explicitly.
revoke all on function public.current_role() from public,anon;
revoke all on function public.is_director() from public,anon;
revoke all on function public.can_view_finance() from public,anon;
revoke all on function public.is_staff() from public,anon;
revoke all on function public.protect_profile_changes() from public,anon;
revoke all on function public.write_audit_log() from public,anon;
revoke all on function public.get_stock_balances(uuid) from public,anon;
revoke all on function public.record_purchase(jsonb) from public,anon;
revoke all on function public.record_sale(jsonb) from public,anon;
revoke all on function public.record_payment(jsonb) from public,anon;
revoke all on function public.update_delivery_status(uuid,text,text) from public,anon;
revoke all on function public.confirm_mpesa_payment(uuid,text) from public,anon,authenticated;
grant execute on function public.current_role(),public.is_director(),public.can_view_finance(),public.is_staff() to authenticated;
grant execute on function public.get_stock_balances(uuid),public.record_purchase(jsonb),public.record_sale(jsonb),public.record_payment(jsonb),public.update_delivery_status(uuid,text,text) to authenticated;

-- Finance views remain available only to finance roles through underlying RLS/grants.
revoke all on public.finance_purchase_detail,public.finance_stock_valuation,public.finance_sales_summary,
  public.finance_profit_summary,public.finance_credit_summary from anon,authenticated;
grant select on public.finance_purchase_detail,public.finance_stock_valuation,public.finance_sales_summary,
  public.finance_profit_summary,public.finance_credit_summary to authenticated;

-- Basic SQL assertions. Full role simulation and callback integration tests are separate.


-- Finance-only owner-executed views. The explicit role predicate is mandatory because
-- these views intentionally bypass base-table RLS to expose restricted financial columns.
create or replace view public.finance_stock_valuation as
select branch_id,product_id,sum(quantity_remaining) quantity_remaining,
       sum(quantity_remaining*unit_cost)::numeric(16,2) stock_value
from public.stock_batches where public.can_view_finance() group by branch_id,product_id;
create or replace view public.finance_sales_summary as
select s.branch_id,date_trunc('month',s.sale_date)::date month,
       count(distinct s.id) sales_count,sum(s.total)::numeric(16,2) sales_revenue
from public.sales s where s.status<>'cancelled' and public.can_view_finance()
group by s.branch_id,date_trunc('month',s.sale_date)::date;
create or replace view public.finance_credit_summary as
select c.id customer_id,c.name,c.phone,
       coalesce(sum(case when l.entry_type in ('credit_sale','adjustment') then l.amount
                         when l.entry_type in ('repayment','reversal') then -l.amount else 0 end),0)::numeric(16,2) balance
from public.customers c left join public.customer_credit_ledger l on l.customer_id=c.id
where public.can_view_finance() group by c.id,c.name,c.phone;


create or replace view public.finance_payment_detail as
select p.id payment_id,p.sale_id,p.customer_id,p.method,p.amount,p.reference,p.provider_verified,p.status,p.paid_at,p.recorded_by
from public.payments p where public.can_view_finance();
revoke all on public.finance_payment_detail from anon,authenticated;
grant select on public.finance_payment_detail to authenticated;


-- Explicitly retain owner-executed view semantics, then enforce the role predicate
-- inside each view definition above.
alter view public.finance_purchase_detail set (security_invoker=false);
alter view public.finance_stock_valuation set (security_invoker=false);
alter view public.finance_sales_summary set (security_invoker=false);
alter view public.finance_profit_summary set (security_invoker=false);
alter view public.finance_credit_summary set (security_invoker=false);
alter view public.finance_payment_detail set (security_invoker=false);
