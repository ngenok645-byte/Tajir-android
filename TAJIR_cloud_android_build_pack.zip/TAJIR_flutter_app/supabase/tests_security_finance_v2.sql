-- TAJIR v2 post-migration verification queries.
-- Run as project owner after both migrations have been applied.

-- 1. Confirm RLS is enabled on every business table.
select n.nspname, c.relname, c.relrowsecurity
from pg_class c join pg_namespace n on n.oid=c.relnamespace
where n.nspname='public' and c.relkind='r'
  and c.relname in ('profiles','branches','products','suppliers','customers','purchases','purchase_items',
    'purchase_expenses','stock_batches','stock_movements','sales','sale_items','stock_allocations',
    'payments','customer_credit_ledger','deliveries','operating_expenses','audit_logs')
order by c.relname;

-- 2. Check that workers do not have direct SELECT on financial columns.
select has_column_privilege('authenticated','public.purchase_items','unit_cost','select') as can_read_purchase_unit_cost,
       has_column_privilege('authenticated','public.stock_batches','unit_cost','select') as can_read_batch_unit_cost,
       has_column_privilege('authenticated','public.sale_items','unit_price','select') as can_read_sale_unit_price,
       has_column_privilege('authenticated','public.sales','total','select') as can_read_sale_total,
       has_table_privilege('authenticated','public.payments','select') as can_read_payment_table;
-- Expected: all five values are false. Finance access is through guarded finance_* views.

-- 3. Check RPC execute privileges. Expected: anon cannot execute any listed function;
-- authenticated can execute staff RPCs, but cannot execute confirm_mpesa_payment.
select p.proname,
       has_function_privilege('anon',p.oid,'execute') as anon_can_execute,
       has_function_privilege('authenticated',p.oid,'execute') as authenticated_can_execute
from pg_proc p join pg_namespace n on n.oid=p.pronamespace
where n.nspname='public' and p.proname in
 ('record_purchase','record_sale','record_payment','update_delivery_status','confirm_mpesa_payment')
order by p.proname;

-- 4. Inspect policies on sensitive tables.
select tablename,policyname,cmd,qual,with_check
from pg_policies where schemaname='public'
 and tablename in ('purchases','purchase_items','purchase_expenses','stock_batches','sales',
                   'sale_items','stock_allocations','payments','customer_credit_ledger','operating_expenses')
order by tablename,policyname;

-- 5. Verify finance views are not accidentally granted to anon.
select table_name,grantee,privilege_type
from information_schema.role_table_grants
where table_schema='public' and table_name like 'finance_%'
order by table_name,grantee;
